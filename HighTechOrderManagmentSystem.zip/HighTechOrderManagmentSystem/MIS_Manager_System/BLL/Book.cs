﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MIS_Manager_System.DAL;

namespace MIS_Manager_System.BLL
{
    public class Book
    {
        private int isbn;
        private string title;
        private int unitPrice;
        private int yearPublished;
        private string publisher;
        private int qoh;
        private string category;
        private int authorId;
        private string firstName;
        private string lastName;
        private string email;

        public int Isbn { get => isbn; set => isbn = value; }
        public string Title { get => title; set => title = value; }
        public int UnitPrice { get => unitPrice; set => unitPrice = value; }
        public int YearPublished { get => yearPublished; set => yearPublished = value; }
        public string Publisher { get => publisher; set => publisher = value; }
        public int Qoh { get => qoh; set => qoh = value; }
        public string Category { get => category; set => category = value; }
        public int AuthorId { get => authorId; set => authorId = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Email { get => email; set => email = value; }

        public List<Book> GetAllBook() // this will return the list
        {
            return DBBook.GetAllRecords();
        }

        public bool IdExist(int bId)               // if the ID is similar
        {
            return DBBook.IsDuplicateId(bId);
        }

        public void SaveBook(Book bk)
        {
            DBBook.SaveRecords(bk);
        }

        public Book SearchBook(int bId)
        {
            return DBBook.SearchRecord(bId);
        }

        public Book SearchBookByAuthorId(int bId)
        {
            return DBBook.SearchRecordByAuthorId(bId);
        }

    }
}
