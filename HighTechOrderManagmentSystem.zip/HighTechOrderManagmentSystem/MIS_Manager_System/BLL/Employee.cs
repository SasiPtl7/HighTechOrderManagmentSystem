﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MIS_Manager_System.DAL;

namespace MIS_Manager_System.BLL
{
    public class Employee
    {
        private int employeeId;
        private string firstName;
        private string lastName;
        private string jobTitle;

        public int EmployeeId { get => employeeId; set => employeeId = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string JobTitle { get => jobTitle; set => jobTitle = value; }

        public void SaveEmployees(Employee emp)
        {
            EmployeeDB.SaveRecords(emp);
        }

        public List<Employee> GetAllEmployees() // this will return the list
        {
            return EmployeeDB.GetAllRecords();
        }

        public Employee SearchEmployee(int eId)
        {
            return EmployeeDB.SearchRecord(eId);
        }

        public bool IdExist(int eId)               // if the ID is similar
        {
            return EmployeeDB.IsDuplicateId(eId);
        }

        public List<Employee> SearchedEmployee(string name)
        {
            return EmployeeDB.SearchRecord(name);
        }
    }
}
