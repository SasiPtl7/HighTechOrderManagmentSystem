﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MIS_Manager_System.DAL;

namespace MIS_Manager_System.BLL
{
    public class UserLogIn
    {
        private int ManagerId;
        private string userName;
        private string password;
        private string email;

       
        public string UserName { get => userName; set => userName = value; }
        public string Password { get => password; set => password = value; }
        public string Email { get => email; set => email = value; }
        public int ManagerId1 { get => ManagerId; set => ManagerId = value; }

        public List<UserLogIn> GetAllUser()
        {
            return DBLogIn.GetAllRecords();
        }

        public UserLogIn SearchManager(int mId)
        {
            return DBLogIn.SearchRecord(mId);
        }
        public bool IdExists(int eId)
        {
            return DBLogIn.IsDuplicateId(eId);
        }
        public void SaveManager(UserLogIn ur)
        {
            DBLogIn.SaveRecord(ur);
        }

        public static bool Checkpassword(string userId, string password)
        {
            return DBLogIn.CheckPassword(userId, password);
        }
    }
}
