﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MIS_Manager_System.DAL;

namespace MIS_Manager_System.BLL
{
    public class Order
    {
        private int orderId;
        private int isbn;
        private int customerId;
        private int quantityOrdered;
        private string status;
        private int payment;

        public int Isbn { get => isbn; set => isbn = value; }
        public int OrderId { get => orderId; set => orderId = value; }
        public int CustomerId { get => customerId; set => customerId = value; }
        public int QuantityOrdered { get => quantityOrdered; set => quantityOrdered = value; }
        public string Status { get => status; set => status = value; }
        public int Payment { get => payment; set => payment = value; }


        public List<Order> GetAllOrder()
        {
            return DBOrder.GetAllRecords();
        }

        public Order SearchOrder(int oId)
        {
            return DBOrder.SearchRecord(oId);
        }

        public void SaveOrder(Order ur)
        {
            DBOrder.SaveRecord(ur);
        }
    }
}
