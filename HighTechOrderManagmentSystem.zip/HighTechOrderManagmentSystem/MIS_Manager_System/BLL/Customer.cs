﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MIS_Manager_System.DAL;

namespace MIS_Manager_System.BLL
{
    public class Customer
    {
        public int customerId { get; set; }
        public string customerName { get; set; }
        public int creditLimit { get; set; }
        public string streetNumber { get; set; }
        public string city { get; set; }
        public string postalCode { get; set; }
        public int phoneNumber { get; set; }
        public int faxNumber { get; set; }
        public string email { get; set; }

        public List<Customer> GetAllCustomer()
        {
            return DBCustomer.GetAllRecords();
        }


    }
}
