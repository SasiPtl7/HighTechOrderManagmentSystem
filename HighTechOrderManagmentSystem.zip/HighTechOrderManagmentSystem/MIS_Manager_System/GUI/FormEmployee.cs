﻿using MIS_Manager_System.BLL;
using MIS_Manager_System.VALIDATION;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MIS_Manager_System.GUI
{
    public partial class FormEmployee : Form
    {
        public FormEmployee()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Do you really want to exit?",
               "Confirm",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                Application.Exit();
        }

        private void btnSaveEmployee_Click(object sender, EventArgs e)
        {

            Employee employee = new Employee();

            // data validation
            // EmployeeId

            string input = "";
            input = tbEmployeeID.Text.Trim();

            if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("Employee ID must be 4-digit number", "Invalid Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeID.Clear();
                tbEmployeeID.Focus();
                return;                          // return matters as it tells the comp that it have to stop and just return
            }

            // check duplicate Id
            if (employee.IdExist(Convert.ToInt32(input)))
            {
                MessageBox.Show("The Employee Id already exist!", "Duplicate Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeID.Clear();
                tbEmployeeID.Focus();
                return;
            }

            // check if Name have Numbers
            input = tbFirstName.Text.Trim();
            if (!Validator.IsValidName(input))
            {
                MessageBox.Show("Invalid First Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbFirstName.Clear();
                tbFirstName.Focus();
                return;
            }

            // check if Last Name have Numbers
            input = tbLastName.Text.Trim();
            if (!Validator.IsValidName(input))
            {
                MessageBox.Show("Invalid Last Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbLastName.Clear();
                tbLastName.Focus();
                return;
            }

            employee.EmployeeId = Convert.ToInt32(tbEmployeeID.Text.Trim());
            employee.FirstName = tbFirstName.Text.Trim();
            employee.LastName = tbLastName.Text.Trim();
            employee.JobTitle = tbJobTitle.Text.Trim();
            employee.SaveEmployees(employee);
            MessageBox.Show("Employee data has been saved successfully", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearAll();
        }

        private void ClearAll()
        {
            tbEmployeeID.Clear();
            tbFirstName.Clear();
            tbLastName.Clear();
            tbJobTitle.Clear();
            tbEmployeeID.Focus();
        }

        private void DisplayEmployeeData(ListView listV, List<Employee> listE)
        {

            listV.Items.Clear();
            foreach (Employee anEmp in listE)
            {
                ListViewItem item = new ListViewItem(anEmp.EmployeeId.ToString());
                item.SubItems.Add(anEmp.FirstName);
                item.SubItems.Add(anEmp.LastName);
                item.SubItems.Add(anEmp.JobTitle);
                listV.Items.Add(item);

            }
        }

        private void btnSearchEmployee_Click(object sender, EventArgs e)
        {
            ClearAll();
            if (cbSearchBy.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the search option.", "Search Option", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int option = cbSearchBy.SelectedIndex;
            int searchId = 0;
            string input = "";
            Employee emp = new Employee();

            switch (option)
            {
                case 0: //search by Employee ID 
                    input = tbMessage.Text.Trim();
                    if (!Validator.IsValidId(input, 4))
                    {
                        MessageBox.Show("Employee Id must be 4-digit number.", "Invalid EmployeeId", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        tbMessage.Clear();
                        tbMessage.Focus();  //cursor go back to the same box if we use focus
                        return;
                    }
                    searchId = Convert.ToInt32(tbMessage.Text);
                    emp = emp.SearchEmployee(searchId);
                    if (emp != null)
                    {
                        tbEmployeeID.Text = emp.EmployeeId.ToString();
                        tbFirstName.Text = emp.FirstName.ToString();
                        tbLastName.Text = emp.LastName.ToString();
                        tbJobTitle.Text = emp.JobTitle.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Employee Not Found!", "Invalid EmployeeId", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    break;
                case 1: //search by Name
                    input = tbMessage.Text.Trim();
                    if (!Validator.IsValidName(input))
                    {
                        MessageBox.Show("Invalid First Name!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        tbMessage.Clear();
                        tbMessage.Focus();
                        return;
                    }
                    List<Employee> empList = emp.SearchedEmployee(input);
                    DisplayEmployeeData(listViewEmployees, empList);
                    break;
                case 2:    //search by Last Name
                    input = tbMessage.Text.Trim();
                    if (!Validator.IsValidName(input))
                    {
                        MessageBox.Show("Invalid Last Name!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        tbMessage.Clear();
                        tbMessage.Focus();
                        return;
                    }
                    List<Employee> empListE = emp.SearchedEmployee(input);
                    DisplayEmployeeData(listViewEmployees, empListE);
                    break;

                default:
                    break;

            }
        }

        private void cbSearchBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            int choice = cbSearchBy.SelectedIndex;
            switch (choice)
            {
                case 0:
                    tbMessage.Clear();
                    tbMessage.Focus();
                    labelMessage.Text = "Please enter Employee ID";
                    break;
                case 1:
                    tbMessage.Clear();
                    tbMessage.Focus();
                    labelMessage.Text = "Please enter First Name";
                    break;
                case 2:
                    tbMessage.Clear();
                    tbMessage.Focus();
                    labelMessage.Text = "Please enter Last Name";
                    break;
                default:
                    break;
            }
        }

        private void btnListEmployees_Click(object sender, EventArgs e)
        {
            ClearAll();
            //cbSearchBy.SelectedIndex == -1;             //Make something so that when user click to LIST, cb becomes back to normal
            Employee emp = new Employee();
            List<Employee> listE = emp.GetAllEmployees();
            listViewEmployees.Items.Clear();
            foreach (Employee employee in listE)
            {
                ListViewItem item = new ListViewItem(employee.EmployeeId.ToString());
                item.SubItems.Add(employee.FirstName);
                item.SubItems.Add(employee.LastName);
                item.SubItems.Add(employee.JobTitle);

                listViewEmployees.Items.Add(item);
            }
        }

        private void btnUpdateEmployee_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Temporary maintenance!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Temporary maintenance!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool AllFieldsAreOK()
        {
            Employee employee = new Employee();

            // data validation
            // EmployeeId

            string input = "";
            input = tbEmployeeID.Text.Trim();

            if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("Employee ID must be 4-digit number", "Invalid Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeID.Clear();
                tbEmployeeID.Focus();
                return false;                          // return matters as it tells the comp that it have to stop and just return
            }

            // check duplicate Id
            if (employee.IdExist(Convert.ToInt32(input)))
            {
                MessageBox.Show("The Employee Id already exist!", "Duplicate Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeID.Clear();
                tbEmployeeID.Focus();
                return false;
            }

            // check if Name have Numbers
            input = tbFirstName.Text.Trim();
            if (!Validator.IsValidName(input))
            {
                MessageBox.Show("Invalid First Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbFirstName.Clear();
                tbFirstName.Focus();
                return false;
            }

            // check if Last Name have Numbers
            input = tbLastName.Text.Trim();
            if (!Validator.IsValidName(input))
            {
                MessageBox.Show("Invalid Last Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbLastName.Clear();
                tbLastName.Focus();
                return false;
            }

            return true;
        }

    }
}
