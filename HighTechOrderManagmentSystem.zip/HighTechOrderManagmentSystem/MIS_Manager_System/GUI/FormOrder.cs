﻿using MIS_Manager_System.BLL;
using MIS_Manager_System.VALIDATION;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MIS_Manager_System.GUI
{
    public partial class FormOrder : Form
    {
        public FormOrder()
        {
            InitializeComponent();
        }

        private void ClearAll()
        {
            tbISBN.Clear();
            tbOrderID.Clear();
            tbQuantityOrdered.Clear();
            tbISBN.Focus();
        }

        private void btnListOrder_Click(object sender, EventArgs e)
        {
            ClearAll();
            Order ord = new Order();
            List<Order> listO = ord.GetAllOrder();
            listViewOrder.Items.Clear();
            foreach (Order order in listO)
            {
                ListViewItem item = new ListViewItem(order.OrderId.ToString());
                item.SubItems.Add(order.Isbn.ToString());
                item.SubItems.Add(order.CustomerId.ToString());
                item.SubItems.Add(order.QuantityOrdered.ToString());
                item.SubItems.Add(order.Status);
                item.SubItems.Add(order.Payment.ToString());

                listViewOrder.Items.Add(item);
            }
        }


        private void btnSearchOrder_Click(object sender, EventArgs e)
        {
            string input = "";
            int searchOrderId = 0;
            input = tbMessage.Text.Trim();
            Order usr = new Order();

            if (tbMessage.Text == "")
            {
                MessageBox.Show("Please type Order Id", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("Order Id must be 4-digit number and Numeric", "Invalid OrderId", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbMessage.Clear();
                tbMessage.Focus();
                return;
            }
            searchOrderId = Convert.ToInt32(tbMessage.Text);
            usr = usr.SearchOrder(searchOrderId);
            if (usr != null)
            {
                tbOrderID.Text = usr.OrderId.ToString();
                tbISBN.Text = usr.Isbn.ToString();
                tbCustomerId.Text = usr.CustomerId.ToString();
                tbQuantityOrdered.Text = usr.QuantityOrdered.ToString();
                tbStatus.Text = usr.Status.ToString();
                tbPayment.Text = usr.Payment.ToString();
            }
            else
            {
                MessageBox.Show("Order Not Found!", "Invalid OrderId", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdateOrder_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Maintenance going on!!");
        }

        private void btnCanceleOrder_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Maintenance going on!!");
        }

        private void btnSaveOrder_Click(object sender, EventArgs e)
        {
            Order user = new Order();

            string input = "";
            input = tbOrderID.Text.Trim();
            if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("OrderId must be 4-digit number", "Invalid Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbOrderID.Clear();
                tbOrderID.Focus();
                return;
            }

            input = tbISBN.Text.Trim();
            if (!Validator.IsValidNumeric(input))
            {
                MessageBox.Show("Invalid tbISBN", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbISBN.Clear();
                tbISBN.Focus();
                return;
            }

            input = tbCustomerId.Text.Trim();
            if (!Validator.IsValidPass(input, 4))
            {
                MessageBox.Show("Invalid Customer Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbCustomerId.Clear();
                tbCustomerId.Focus();
                return;
            }

            input = tbQuantityOrdered.Text.Trim();
            if (!Validator.IsValidNumeric(input))
            {
                MessageBox.Show("Quantity Ordered should be numeric", "Invalid Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbQuantityOrdered.Clear();
                tbQuantityOrdered.Focus();
                return;
            }

            input = tbStatus.Text.Trim();
            if (tbStatus.Text == "")
            {
                MessageBox.Show("Invalid Status", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbStatus.Clear();
                tbStatus.Focus();
                return;
            }

            input = tbPayment.Text.Trim();
            if (!Validator.IsValidNumeric(input))
            {
                MessageBox.Show("Payment should be numeric", "Invalid Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbPayment.Clear();
                tbPayment.Focus();
                return;
            }

            user.OrderId = Convert.ToInt32(tbOrderID.Text.Trim());
            user.Isbn = Convert.ToInt32(tbISBN.Text.Trim());
            user.CustomerId = Convert.ToInt32(tbCustomerId.Text.Trim());
            user.QuantityOrdered = Convert.ToInt32(tbQuantityOrdered.Text.Trim());
            user.Status = tbStatus.Text.Trim();
            user.Payment = Convert.ToInt32(tbPayment.Text.Trim());
            user.SaveOrder(user);

            MessageBox.Show("Order data has been saved successfully.", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearAll();
        }
    }
}
