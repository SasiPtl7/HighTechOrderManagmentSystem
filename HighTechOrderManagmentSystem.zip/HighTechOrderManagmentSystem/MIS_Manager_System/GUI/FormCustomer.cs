﻿using MIS_Manager_System.BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using MIS_Manager_System.BLL;
using System.Data.SqlClient;
using MIS_Manager_System.DAL;

namespace MIS_Manager_System.GUI
{
    public partial class FormCustomer : Form
    {
        SqlDataAdapter da;
        DataSet dsCustomerDB;
        DataTable dtCustomer;
        SqlCommandBuilder sqlBuilder;
        public FormCustomer()
        {
            InitializeComponent();
        }

        private void btnListCustomer_Click(object sender, EventArgs e)
        {
            Customer cx = new Customer();
            List<Customer> cxList = cx.GetAllCustomer();
            dataGridViewCustomer.DataSource = cxList;
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Temporary maintenance!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Temporary maintenance!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void ClearAll()
        {
            tbCustomerName.Clear();
            tbCreditLimit.Clear();
            tbStreetAdress.Clear();
            tbCity.Clear();
            tbPostalCode.Clear();
            tbPhoneNumber.Clear();
            tbFaxNumber.Clear();
            tbEmail.Clear();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            int searchId = Convert.ToInt32(tbCustomerId.Text.Trim());
            DataRow dr = dtCustomer.Rows.Find(searchId);
            if (dr != null)
            {
                tbCustomerName.Text = dr["CustomerName"].ToString();
                tbCreditLimit.Text = dr["CreditLimit"].ToString();
                tbStreetAdress.Text = dr["StreetName"].ToString();
                tbCity.Text = dr["City"].ToString();
                tbPostalCode.Text = dr["PostalCode"].ToString();
                tbPhoneNumber.Text = dr["PhoneNumber"].ToString();
                tbFaxNumber.Text = dr["FaxNumber"].ToString();
                tbEmail.Text = dr["Email"].ToString();
            }
            else
            {
                MessageBox.Show("Customer not found!", "Invalid CustomerId",
                                 MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            DataRow dr = dtCustomer.NewRow();
            dr["CustomerName"] = tbCustomerName.Text.Trim();
            dr["CreditLimit"] = tbCreditLimit.Text.Trim();
            dr["StreetName"] = tbStreetAdress.Text.Trim();
            dr["City"] = tbCity.Text.Trim();
            dr["PostalCode"] = tbPostalCode.Text.Trim();
            dr["PhoneNumber"] = tbPhoneNumber.Text.Trim();
            dr["FaxNumber"] = tbFaxNumber.Text.Trim();
            dr["Email"] = tbEmail.Text.Trim();

            dtCustomer.Rows.Add(dr);
            MessageBox.Show("RowState : " + dr.RowState);

            da.Update(dsCustomerDB.Tables["Customer"]);
            MessageBox.Show("Database has been updated successfully.", "Confirmation");
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Do you really want to exit?",
              "Confirm",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                Application.Exit();
        }

        private void FormCustomer_Load(object sender, EventArgs e)
        {
            dsCustomerDB = new DataSet("CustomerDS");
            dtCustomer = new DataTable("Customer");
            dtCustomer.Columns.Add("CustomerId", typeof(int));
            dtCustomer.Columns.Add("CustomerName", typeof(string));
            dtCustomer.Columns.Add("CreditLimit", typeof(int));
            dtCustomer.Columns.Add("StreetName", typeof(string));
            dtCustomer.Columns.Add("City", typeof(string));
            dtCustomer.Columns.Add("PostalCode", typeof(string));
            dtCustomer.Columns.Add("PhoneNumber", typeof(int));
            dtCustomer.Columns.Add("FaxNumber", typeof(int));
            dtCustomer.Columns.Add("Email", typeof(string));


            //set a primary key
            dtCustomer.PrimaryKey = new DataColumn[] { dtCustomer.Columns["CustomerId"] };
            dtCustomer.Columns["CustomerId"].AutoIncrement = true;
            dtCustomer.Columns["CustomerId"].AutoIncrementSeed = 1111111;
            dtCustomer.Columns["CustomerId"].AutoIncrementStep = 1;

            // we need this lower line otherwise it will be outside the table
            dsCustomerDB.Tables.Add(dtCustomer);
            da = new SqlDataAdapter();
            sqlBuilder = new SqlCommandBuilder(da); //link the build command
            da.SelectCommand = new SqlCommand("SELECT * FROM Customer", DBUtility.GetDBConnectionCustomer());
            da.TableMappings.Add("Customer", "Customer"); //map table source with inner table
            da.Fill(dsCustomerDB, "Customer");
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Customer cx = new Customer();
            List<Customer> cxList = cx.GetAllCustomer();
            dataGridViewCustomer.DataSource = cxList;
        }
    }
}
