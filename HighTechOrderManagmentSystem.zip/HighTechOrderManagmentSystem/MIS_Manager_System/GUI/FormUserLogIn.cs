﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MIS_Manager_System.DAL;
using MIS_Manager_System.BLL;
using MIS_Manager_System.VALIDATION;
using System.Xml.Linq;
using Microsoft.VisualBasic.ApplicationServices;
using System.Security.Policy;

namespace MIS_Manager_System.GUI
{

    public partial class FormUserLogIn : Form
    {
        public FormUserLogIn()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ClearAll();

            UserLogIn ur = new UserLogIn();
            List<UserLogIn> listU = ur.GetAllUser();
            listViewUserEmployees.Items.Clear();
            foreach (UserLogIn User in listU)
            {
                ListViewItem item = new ListViewItem(User.ManagerId1.ToString());
                item.SubItems.Add(User.UserName);
                item.SubItems.Add(User.Email);

                listViewUserEmployees.Items.Add(item);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Do you really want to exit?",
                "Confirm",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                Application.Exit();
        }


        private void btnSearchManager_Click(object sender, EventArgs e)
        {
            string input = "";
            int searchId = 0;
            input = tbMessage.Text.Trim();
            UserLogIn usr = new UserLogIn();

            if (tbMessage.Text == "")
            {
                MessageBox.Show("Please type Manager Id", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("Manager Id must be 4-digit number and Numeric", "Invalid ManagerId", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbMessage.Clear();
                tbMessage.Focus();
                return;
            }
            searchId = Convert.ToInt32(tbMessage.Text);
            usr = usr.SearchManager(searchId);
            if (usr != null)
            {
                tbUserName.Text = usr.UserName.ToString();
                tbPassword.Text = usr.Password.ToString();
                tbEmployeeId.Text = usr.ManagerId1.ToString();
                tbEmail.Text = usr.Email.ToString();
            }
            else
            {
                MessageBox.Show("Manager Not Found!", "Invalid ManagerId", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void ClearAll()
        {
            tbUserName.Clear();
            tbPassword.Clear();
            tbEmployeeId.Clear();
            tbEmail.Clear();
            tbMessage.Clear();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            UserLogIn user = new UserLogIn();

            string input = "";
            input = tbEmployeeId.Text.Trim();
            if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("EmployeeId must be 4-digit number", "Invalid Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeId.Clear();
                tbEmployeeId.Focus();
                return;
            }

            if (user.IdExists(Convert.ToInt32(input)))
            {
                MessageBox.Show("This ManagerId already exists!", "Duplicate Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeId.Clear();
                tbEmployeeId.Focus();
                return;
            }

            input = tbUserName.Text.Trim();
            if (!Validator.IsValidName(input))
            {
                MessageBox.Show("Invalid Username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbUserName.Clear();
                tbUserName.Focus();
                return;
            }

            input = tbPassword.Text.Trim();
            if (!Validator.IsValidPass(input, 4))
            {
                MessageBox.Show("Invalid Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbPassword.Clear();
                tbPassword.Focus();
                return;
            }

            input = tbEmail.Text.Trim();
            if (tbEmail.Text == "")
            {
                MessageBox.Show("Invalid Email", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbPassword.Clear();
                tbPassword.Focus();
                return;
            }

            user.ManagerId1 = Convert.ToInt32(tbEmployeeId.Text.Trim());
            user.UserName = tbUserName.Text.Trim();
            user.Password = tbPassword.Text.Trim();
            user.Email = tbEmail.Text.Trim();
            user.SaveManager(user);
            MessageBox.Show("Manager data has been saved successfully.", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearAll();
        }

        private bool AllFieldsAreOk()
        {
            if (tbEmployeeId.Text == "")
            {
                MessageBox.Show("Please type Manager Id");
                return false;
            }
            else if (tbUserName.Text == "")
            {
                MessageBox.Show("Please type Username");
                return false;
            }
            else if (tbPassword.Text == "")
            {
                MessageBox.Show("Please generate Password");
                return false;
            }
            else if (tbEmail.Text == "")
            {
                MessageBox.Show("Please type Emaid id");
                return false;
            }

            return true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!AllFieldsAreOk())
                return;

            UserLogIn user = new UserLogIn();

            string input = "";
            input = tbEmployeeId.Text.Trim();
            if (!Validator.IsValidId(input, 4))
            {
                MessageBox.Show("EmployeeId must be 4-digit number", "Invalid Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeId.Clear();
                tbEmployeeId.Focus();
                return;
            }

            if (user.IdExists(Convert.ToInt32(input)))
            {
                MessageBox.Show("This ManagerId already exists!", "Duplicate Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmployeeId.Clear();
                tbEmployeeId.Focus();
                return;
            }


            input = tbUserName.Text.Trim();
            if (!Validator.IsValidName(input))
            {
                MessageBox.Show("Invalid Username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbUserName.Clear();
                tbUserName.Focus();
                return;
            }

            input = tbPassword.Text.Trim();
            if (!Validator.IsValidPass(input, 4))
            {
                MessageBox.Show("Invalid Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbPassword.Clear();
                tbPassword.Focus();
                return;
            }

            user.ManagerId1 = Convert.ToInt32(tbEmployeeId.Text);
            user.UserName = tbUserName.Text;
            user.Password = tbPassword.Text;
            user.Email = tbEmail.Text;

            user.SaveManager(user);

            MessageBox.Show("Manager has been updated");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Maintenance going on!!");
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string input = "";

            input = tbUserName.Text.Trim();
            if (!Validator.IsValidName(input))
            {
                MessageBox.Show("Invalid Username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbUserName.Clear();
                tbUserName.Focus();
                return;
            }

            input = tbPassword.Text.Trim();
            if (!Validator.IsValidPass(input, 4))
            {
                MessageBox.Show("Invalid Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbPassword.Clear();
                tbPassword.Focus();
                return;
            }

            int option = cbLogIn.SelectedIndex;
            UserLogIn bk = new UserLogIn();

            switch (option)
            {
                case 0:
                    string userId = tbUserName.Text.Trim();
                    string password = tbPassword.Text.Trim();

                    if (UserLogIn.Checkpassword(userId, password))
                    {
                        var mainForm = new FormEmployee();
                        mainForm.Show();
                        this.Hide();

                        MessageBox.Show("You are logged in succesfully :)");
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password!!");
                        tbPassword.Clear();
                    }
                    break;
                case 1:
                    string uId = tbUserName.Text.Trim();
                    string pass = tbPassword.Text.Trim();

                    if (UserLogIn.Checkpassword(uId, pass))
                    {
                        var mainForm = new FormCustomer();
                        mainForm.Show();
                        this.Hide();

                        MessageBox.Show("You are logged in succesfully :)");
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password!!");
                        tbPassword.Clear();
                    }
                    break;
                case 2:
                    string usId = tbUserName.Text.Trim();
                    string passw = tbPassword.Text.Trim();

                    if (UserLogIn.Checkpassword(usId, passw))
                    {
                        var mainForm = new FormBook();
                        mainForm.Show();
                        this.Hide();

                        MessageBox.Show("You are logged in succesfully :)");
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password!!");
                        tbPassword.Clear();
                    }
                    break;
                case 3:
                    string usrId = tbUserName.Text.Trim();
                    string passwd = tbPassword.Text.Trim();

                    if (UserLogIn.Checkpassword(usrId, passwd))
                    {
                        var mainForm = new FormOrder();
                        mainForm.Show();
                        this.Hide();

                        MessageBox.Show("You are logged in succesfully :)");
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password!!");
                        tbPassword.Clear();
                    }
                    break;

                default:
                    break;
            }
        }
    }
}
