﻿using MIS_Manager_System.BLL;
using MIS_Manager_System.DAL;
using MIS_Manager_System.VALIDATION;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MIS_Manager_System.GUI
{
    public partial class FormBook : Form
    {
        public FormBook()
        {
            InitializeComponent();
        }


        private void ClearAll()
        {
            tbISBN.Clear();
            tbTitle.Clear();
            tbUnitPrice.Clear();
            tbYearPublished.Clear();
            tbYearPublished.Clear();
            tbPublisher.Clear();
            tbQOH.Clear();
            tbCategory.Clear();
            tbAuthorId.Clear();
            tbFirstName.Clear();
            tbLastName.Clear();
            tbEmail.Clear();
            tbISBN.Focus();
        }


        private void btnList_Click(object sender, EventArgs e)
        {
            ClearAll();
           
            Book bks = new Book();
            List<Book> listB = bks.GetAllBook();
            listViewBook.Items.Clear();
            foreach (Book bk in listB)
            {
                ListViewItem item = new ListViewItem(bk.Isbn.ToString());
                item.SubItems.Add(bk.Title);
                item.SubItems.Add(bk.UnitPrice.ToString());
                item.SubItems.Add(bk.YearPublished.ToString());
                item.SubItems.Add(bk.Publisher);
                item.SubItems.Add(bk.Qoh.ToString());
                item.SubItems.Add(bk.Category.ToString());
                item.SubItems.Add(bk.AuthorId.ToString());
                item.SubItems.Add(bk.LastName);
                item.SubItems.Add(bk.FirstName);
                item.SubItems.Add(bk.Email);

                listViewBook.Items.Add(item);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Do you really want to exit?",
              "Confirm",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
                Application.Exit();
        }

        private bool AllFieldsAreOK()
        {
            Book bk = new Book();


            string input = "";
            input = tbISBN.Text.Trim();

            if (!Validator.IsValidId(input, 9))
            {
                MessageBox.Show("ISBN must be 9-digit number", "Invalid ISBN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbISBN.Clear();
                tbISBN.Focus();
                return false;                          // return matters as it tells the comp that it have to stop and just return
            }

            input = tbISBN.Text.Trim();
            if (bk.IdExist(Convert.ToInt32(input)))
            {
                MessageBox.Show("The Employee Id already exist!", "Duplicate Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbISBN.Clear();
                tbISBN.Focus();
                return false;
            }

            input = tbTitle.Text.Trim();
            if (!Validator.IsValidName(input) && (tbTitle.Text == ""))
            {
                MessageBox.Show("Invalid Title Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbTitle.Clear();
                tbTitle.Focus();
                return false;
            }

            input = tbUnitPrice.Text.Trim();
            if (tbUnitPrice.Text == "" && !Validator.IsValidNumeric(input))
            {
                MessageBox.Show("Price should be numeric", "Invalid Price", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbUnitPrice.Clear();
                tbUnitPrice.Focus();
                return false;                          // return matters as it tells the comp that it have to stop and just return
            }


            input = tbYearPublished.Text.Trim();
            if (!Validator.IsValidId(input, 4) && tbYearPublished.Text=="")
            {
                MessageBox.Show("Year must be 4-digit number", "Invalid Year", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbYearPublished.Clear();
                tbYearPublished.Focus();
                return false;                          // return matters as it tells the comp that it have to stop and just return
            }

            input = tbPublisher.Text.Trim();
            if (!Validator.IsValidName(input) && tbPublisher.Text == "")
            {
                MessageBox.Show("Invalid Publisher Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbPublisher.Clear();
                tbPublisher.Focus();
                return false;
            }

            input = tbQOH.Text.Trim();
            if (tbQOH.Text == "" && !Validator.IsValidNumeric(input))
            {
                MessageBox.Show("Quantity on hand must be numeric", "Invalid QOH", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbQOH.Clear();
                tbQOH.Focus();
                return false;                          // return matters as it tells the comp that it have to stop and just return
            }

            input = tbCategory.Text.Trim();
            if (!Validator.IsValidName(input) && tbCategory.Text == "")
            {
                MessageBox.Show("Invalid Category Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbCategory.Clear();
                tbCategory.Focus();
                return false;
            }

            input = tbAuthorId.Text.Trim();
            if (!Validator.IsValidId(input, 4) && (tbAuthorId.Text == ""))
            {
                MessageBox.Show("ISBN must be 4-digit number", "Invalid AuthorId", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbAuthorId.Clear();
                tbAuthorId.Focus();
                return false;                          // return matters as it tells the comp that it have to stop and just return
            }

            input = tbAuthorId.Text.Trim();
            if (bk.IdExist(Convert.ToInt32(input)))
            {
                MessageBox.Show("The Author Id already exist!", "Duplicate Id", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbISBN.Clear();
                tbISBN.Focus();
                return false;
            }

            input = tbFirstName.Text.Trim();
            if (!Validator.IsValidName(input) && tbFirstName.Text == "")
            {
                MessageBox.Show("Invalid First Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbFirstName.Clear();
                tbFirstName.Focus();
                return false;
            }


            input = tbLastName.Text.Trim();
            if (!Validator.IsValidName(input) && tbLastName.Text == "")
            {
                MessageBox.Show("Invalid Last Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbLastName.Clear();
                tbLastName.Focus();
                return false;
            }

            input = tbEmail.Text.Trim();
            if (tbEmail.Text == "")
            {
                MessageBox.Show("Email is invalid", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tbEmail.Clear();
                tbEmail.Focus();
                return false;                          // return matters as it tells the comp that it have to stop and just return
            }

            return true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Temporary maintenance!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Temporary maintenance!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }


        private void DisplayBookData(ListView listb, List<Book> listbk)
        {

            listb.Items.Clear();
            foreach (Book bk in listbk)
            {
                ListViewItem item = new ListViewItem(bk.AuthorId.ToString());
                item.SubItems.Add(bk.Isbn.ToString());
                item.SubItems.Add(bk.Title);
                item.SubItems.Add(bk.UnitPrice.ToString());
                item.SubItems.Add(bk.YearPublished.ToString());
                item.SubItems.Add(bk.Publisher);
                item.SubItems.Add(bk.Qoh.ToString());
                item.SubItems.Add(bk.Category.ToString());
                item.SubItems.Add(bk.LastName);
                item.SubItems.Add(bk.FirstName);
                item.SubItems.Add(bk.Email);


                listb.Items.Add(item);

            }
        }


        private void btnSearchBook_Click(object sender, EventArgs e)
        {
            ClearAll();
            if (cbSearchBy.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the search option.", "Search Option", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int option = cbSearchBy.SelectedIndex;
            int searchId = 0;

            string input = "";
            Book bk = new Book();

            switch (option)
            {
                case 0: //search by ISBN 
                    input = tbMessage.Text.Trim();
                    if (!Validator.IsValidId(input, 9))
                    {
                        MessageBox.Show("ISBN must be 9-digit number.", "Invalid ISBN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        tbMessage.Clear();
                        tbMessage.Focus();  //cursor go back to the same box if we use focus
                        return;
                    }
                    searchId = Convert.ToInt32(tbMessage.Text);
                    bk = bk.SearchBook(searchId); // start from here
                    if (bk != null)
                    {
                        tbISBN.Text = bk.Isbn.ToString();
                        tbTitle.Text = bk.Title.ToString();
                        tbUnitPrice.Text = bk.UnitPrice.ToString();
                        tbYearPublished.Text = bk.YearPublished.ToString();
                        tbPublisher.Text = bk.Publisher.ToString();
                        tbQOH.Text = bk.Qoh.ToString();
                        tbCategory.Text = bk.Category.ToString();
                        tbAuthorId.Text = bk.AuthorId.ToString();
                        tbFirstName.Text = bk.FirstName.ToString();
                        tbLastName.Text = bk.LastName.ToString();
                        tbEmail.Text = bk.Email.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Book Not Found!", "Invalid ISBN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    break;
                case 1: //search by Name
                    input = tbMessage.Text.Trim();
                    if (!Validator.IsValidId(input, 4))
                    {
                        MessageBox.Show("Invalid Author Id!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        tbMessage.Clear();
                        tbMessage.Focus();
                        return;
                    }
                    searchId = Convert.ToInt32(tbMessage.Text);
                    bk = bk.SearchBookByAuthorId(searchId); // start from here
                    if (bk != null)
                    {
                        tbISBN.Text = bk.Isbn.ToString();
                        tbTitle.Text = bk.Title.ToString();
                        tbUnitPrice.Text = bk.UnitPrice.ToString();
                        tbYearPublished.Text = bk.YearPublished.ToString();
                        tbPublisher.Text = bk.Publisher.ToString();
                        tbQOH.Text = bk.Qoh.ToString();
                        tbCategory.Text = bk.Category.ToString();
                        tbAuthorId.Text = bk.AuthorId.ToString();
                        tbFirstName.Text = bk.FirstName.ToString();
                        tbLastName.Text = bk.LastName.ToString();
                        tbEmail.Text = bk.Email.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Book Not Found!", "Invalid AuthorId", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    break;

                default:
                    break;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Book bk = new Book();
            AllFieldsAreOK();

            //employee.EmployeeId = Convert.ToInt32(tbEmployeeID.Text.Trim());
            //employee.FirstName = tbFirstName.Text.Trim();
            //employee.LastName = tbLastName.Text.Trim();
            //employee.JobTitle = tbJobTitle.Text.Trim();
            //employee.SaveEmployees(employee);
            //MessageBox.Show("Employee data has been saved successfully", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //ClearAll();


            bk.Isbn = Convert.ToInt32(tbISBN.Text.Trim());
            bk.Title = tbTitle.Text.Trim();
            bk.UnitPrice = Convert.ToInt32(tbUnitPrice.Text.Trim());
            bk.YearPublished = Convert.ToInt32(tbYearPublished.Text.Trim());
            bk.Publisher = tbPublisher.Text.Trim();
            bk.Qoh = Convert.ToInt32(tbQOH.Text.Trim());
            bk.Category = tbCategory.Text.Trim();
            bk.AuthorId = Convert.ToInt32(tbAuthorId.Text.Trim());
            bk.FirstName = tbFirstName.Text.Trim();
            bk.LastName = tbLastName.Text.Trim();
            bk.Email = tbEmail.Text.Trim();
            bk.SaveBook(bk);
            MessageBox.Show("Book data has been saved successfully", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearAll();
        }
    }
}
