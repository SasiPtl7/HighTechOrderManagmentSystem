﻿using MIS_Manager_System.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MIS_Manager_System.DAL.DBUtility;

namespace MIS_Manager_System.DAL
{
    public static class EmployeeDB
    {
        public static void SaveRecords(Employee emp)
        {
            //Insert into Employees
            //Values(1233, 'Vraj', 'Patel', 'Engineer');

            SqlConnection conn = DBUtility.GetDBConnectionEmployee();  //connect DB

            try
            {
                //create and customize an object of SqlCommand

                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = conn;
                cmdInsert.CommandText = "INSERT INTO Employees (EmployeeId,FirstName,LastName,JobTitle)" +
                    " VALUES(@EmployeeId,@FirstName,@LastName,@JobTitle)";

                cmdInsert.Parameters.AddWithValue("@EmployeeId", emp.EmployeeId);
                cmdInsert.Parameters.AddWithValue("@FirstName", emp.FirstName);
                cmdInsert.Parameters.AddWithValue("@LastName", emp.LastName);
                cmdInsert.Parameters.AddWithValue("@JobTitle", emp.JobTitle);
                cmdInsert.ExecuteNonQuery();            //Excute the inserted query
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally                          //clean the code and close database
            {
                conn.Close();                //close DB
                conn.Dispose();              //perform the job right away, will dispose the garbage
            }

        }

        public static List<Employee> GetAllRecords()   // for all the employees
        {
            List<Employee> listE = new List<Employee>();
            SqlCommand cmdSelectAll = new SqlCommand("SELECT * FROM Employees", DBUtility.GetDBConnectionEmployee());      ///check here
            SqlDataReader reader = cmdSelectAll.ExecuteReader();
            Employee emp;
            while (reader.Read())
            {
                emp = new Employee();
                emp.EmployeeId = Convert.ToInt32(reader["EmployeeId"]);
                emp.FirstName = reader["FirstName"].ToString();
                emp.LastName = reader["LastName"].ToString();
                emp.JobTitle = reader["JobTitle"].ToString();
                listE.Add(emp);
            }
            return listE;
        }

        public static Employee SearchRecord(int sID)  // Search by ID
        {
            Employee emp = new Employee();
            SqlConnection conn = DBUtility.GetDBConnectionEmployee();
            SqlCommand cmdSelectById = new SqlCommand();
            cmdSelectById.Connection = conn;
            cmdSelectById.CommandText = "SELECT * FROM Employees " + "WHERE EmployeeId = @EmployeeId";
            cmdSelectById.Parameters.AddWithValue("@EmployeeId", sID);
            SqlDataReader reader = cmdSelectById.ExecuteReader();
            if (reader.Read())
            {
                emp.EmployeeId = Convert.ToInt32(reader["EmployeeId"]);
                emp.FirstName = reader["FirstName"].ToString();
                emp.LastName = reader["LastName"].ToString();
                emp.JobTitle = reader["JobTitle"].ToString();
            }
            else
            {
                emp = null;
            }
            return emp;

        }

        public static List<Employee> SearchRecord(string name)  // Search By Name
        {
            List<Employee> employeeByName = new List<Employee>();

            string sqlSelect = "SELECT * FROM Employees " +
                "WHERE FirstName = @FirstName " +
                "  or  LastName  = @LastName";

            SqlCommand cmdSelectAll = new SqlCommand(sqlSelect, DBUtility.GetDBConnectionEmployee());
            cmdSelectAll.Parameters.AddWithValue("@FirstName", name);
            cmdSelectAll.Parameters.AddWithValue("@LastName", name);
            SqlDataReader reader = cmdSelectAll.ExecuteReader();
            Employee emp;
            while (reader.Read())
            {
                //at the end stop
                emp = new Employee();
                emp.EmployeeId = Convert.ToInt32(reader["EmployeeId"]);
                emp.FirstName = reader["FirstName"].ToString();
                emp.LastName = reader["LastName"].ToString();
                emp.JobTitle = reader["JobTitle"].ToString();
                employeeByName.Add(emp);
            }

            return employeeByName;

        }

        public static bool IsDuplicateId(int id)
        {
            Employee emp = new Employee();
            emp = SearchRecord(id);
            if (emp != null)
            {
                return true;
            }
            return false;
        }
    }
}
