﻿using MIS_Manager_System.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MIS_Manager_System.DAL.DBUtility;

namespace MIS_Manager_System.DAL
{
    public class DBLogIn
    {

        public static bool CheckPassword(string userid, string password)
        {
            using (SqlConnection newconnection = DBUtility.GetDBConnection())
            {
                SqlCommand command = new SqlCommand
                {
                    CommandText = "Select Password from UserLogIn Where UserName = @Userid",
                    Connection = newconnection

                };
                command.Parameters.AddWithValue("@Userid", userid);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    string DbPassword = reader.GetSqlString(0).ToString();
                    if (password == DbPassword)
                        return true;
                    else
                        return false;

                }
                return false;
            }
        }

            public static List<UserLogIn> GetAllRecords()
            {
                List<UserLogIn> listU = new List<UserLogIn>();
                SqlCommand cmdSelectAll = new SqlCommand("SELECT * FROM UserLogIn", DBUtility.GetDBConnection());
                SqlDataReader reader = cmdSelectAll.ExecuteReader();
                UserLogIn ur;
                while (reader.Read())
                {
                    ur = new UserLogIn();
                    ur.ManagerId1 = Convert.ToInt32(reader["ManagerId"]);
                    ur.UserName = reader["UserName"].ToString();
                    ur.Password = reader["Password"].ToString();
                    ur.Email = reader["Email"].ToString();
                    listU.Add(ur);
                }
                return listU;
            }

            public static UserLogIn SearchRecord(int sID)  // Search by ID
            {
                UserLogIn usr = new UserLogIn();
                SqlConnection conn = DBUtility.GetDBConnection();
                SqlCommand cmdSelectById = new SqlCommand();
                cmdSelectById.Connection = conn;
                cmdSelectById.CommandText = "SELECT * FROM UserLogIn " + "WHERE ManagerId = @ManagerId";
                cmdSelectById.Parameters.AddWithValue("@ManagerId", sID);
                SqlDataReader reader = cmdSelectById.ExecuteReader();
                if (reader.Read())
                {
                    usr.ManagerId1 = Convert.ToInt32(reader["ManagerId"]);
                    usr.UserName = reader["UserName"].ToString();
                    usr.Password = reader["Password"].ToString();
                    usr.Email = reader["Email"].ToString();
                }
                else
                {
                    usr = null;
                }
                return usr;

            }

            public static bool IsDuplicateId(int id)
            {
                UserLogIn ur = new UserLogIn();
                ur = SearchRecord(id);
                if (ur != null)
                {
                    return true;
                }
                return false;
            }

            public static void SaveRecord(UserLogIn ur)
            {
                SqlConnection conn = DBUtility.GetDBConnection();
                try
                {
                    SqlCommand cmdInsert = new SqlCommand();
                    cmdInsert.Connection = conn;
                    cmdInsert.CommandText = "INSERT INTO UserLogIn (ManagerId,UserName,Password,Email)" +
                                            " VALUES(@ManagerId,@UserName,@Password,@Email)";

                    cmdInsert.Parameters.AddWithValue("@ManagerId", ur.ManagerId1);
                    cmdInsert.Parameters.AddWithValue("@UserName", ur.UserName);
                    cmdInsert.Parameters.AddWithValue("@Password", ur.Password);
                    cmdInsert.Parameters.AddWithValue("@Email", ur.Email);
                    cmdInsert.ExecuteNonQuery();

                }
                catch (SqlException ex)
                {

                    throw ex;
                }
                finally
                {
                    //close DB
                    conn.Close();
                    conn.Dispose();
                }
            }
        }
    }
