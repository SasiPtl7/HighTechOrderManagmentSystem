﻿using MIS_Manager_System.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MIS_Manager_System.DAL
{
    public static class DBOrder
    {
        public static List<Order> GetAllRecords()
        {
            List<Order> listO = new List<Order>();
            SqlCommand cmdSelectAll = new SqlCommand("SELECT * FROM Order", DBUtility.GetDBConnectionOrder());
            SqlDataReader reader = cmdSelectAll.ExecuteReader();
            Order ord;
            while (reader.Read())
            {
                ord = new Order();
                ord.OrderId = Convert.ToInt32(reader["OrderId"]);
                ord.Isbn = Convert.ToInt32(reader["Isbn"]);
                ord.CustomerId = Convert.ToInt32(reader["CustomerId"]);
                ord.QuantityOrdered = Convert.ToInt32(reader["QuantityOrdered"]);
                ord.Status = Convert.ToString(reader["Status"]);
                ord.Payment = Convert.ToInt32(reader["Payment"]);
                listO.Add(ord);
            }
            return listO;
        }

        public static Order SearchRecord(int oID)  // Search by ID
        {
            Order ord = new Order();
            SqlConnection conn = DBUtility.GetDBConnectionOrder();
            SqlCommand cmdSelectById = new SqlCommand();
            cmdSelectById.Connection = conn;
            cmdSelectById.CommandText = "SELECT * FROM Order " + "WHERE OrderId = @OrderId";
            cmdSelectById.Parameters.AddWithValue("@OrderId", oID);
            SqlDataReader reader = cmdSelectById.ExecuteReader();
            if (reader.Read())
            {
                ord.OrderId = Convert.ToInt32(reader["OrderId"]);
                ord.CustomerId = Convert.ToInt32(reader["CustomerId"]);
                ord.Isbn = Convert.ToInt32(reader["Isbn"]);
                ord.QuantityOrdered = Convert.ToInt32(reader["QuantityOrdered"]);
                ord.Status = reader["Status"].ToString();
                ord.Payment = Convert.ToInt32(reader["Payment"]);
            }
            else
            {
                ord = null;
            }
            return ord;


        }

        public static void SaveRecord(Order ur)
        {
            SqlConnection conn = DBUtility.GetDBConnectionOrder();
            try
            {
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = conn;
                cmdInsert.CommandText = "INSERT INTO Order (Isbn,OrderId,CustomerId,QuantityOrdered,Status,Payment)" +
                                        " VALUES(@Isbn,@OrderId,@CustomerId,@QuantityOrdered,@Status,@Payment)";

                cmdInsert.Parameters.AddWithValue("@Isbn", ur.Isbn);
                cmdInsert.Parameters.AddWithValue("@OrderId", ur.OrderId);
                cmdInsert.Parameters.AddWithValue("@CustomerId", ur.CustomerId);
                cmdInsert.Parameters.AddWithValue("@QuantityOrdered", ur.QuantityOrdered);
                cmdInsert.Parameters.AddWithValue("@Status", ur.Status);
                cmdInsert.Parameters.AddWithValue("@Payment", ur.Payment);
                cmdInsert.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {

                throw ex;
            }
            finally
            {
                //close DB
                conn.Close();
                conn.Dispose();
            }

        }
    }
}
