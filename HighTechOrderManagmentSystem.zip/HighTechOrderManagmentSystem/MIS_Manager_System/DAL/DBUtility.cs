﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace MIS_Manager_System.DAL
{
    public static class DBUtility
    {
        public static SqlConnection GetDBConnection()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;

            conn.Open();
            return conn;
        }

        public static SqlConnection GetDBConnectionEmployee()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionEmployee"].ConnectionString;

            conn.Open();
            return conn;
        }

        public static SqlConnection GetDBConnectionCustomer()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionCustomer"].ConnectionString;

            conn.Open();
            return conn;
        }

        public static SqlConnection GetDBConnectionBook()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionBook"].ConnectionString;

            conn.Open();
            return conn;
        }

        public static SqlConnection GetDBConnectionOrder()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionOrder"].ConnectionString;

            conn.Open();
            return conn;
        }
    }
}
