﻿using MIS_Manager_System.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using static MIS_Manager_System.DAL.DBUtility;


namespace MIS_Manager_System.DAL
{
    public static class DBBook
    {

        public static List<Book> GetAllRecords()   // for all the employees
        {
            List<Book> listB = new List<Book>();
            SqlCommand cmdSelectAll = new SqlCommand("SELECT * FROM Book", DBUtility.GetDBConnectionBook());      ///check here
            SqlDataReader reader = cmdSelectAll.ExecuteReader();
            Book bk;
            while (reader.Read())
            {
                bk = new Book();

                bk.Isbn = Convert.ToInt32(reader["ISBN"]);
                bk.AuthorId = Convert.ToInt32(reader["AuthorId"]);
                bk.Title = reader["Title"].ToString();
                bk.UnitPrice = Convert.ToInt32(reader["UnitPrize"]);
                bk.YearPublished = Convert.ToInt32(reader["YearPublished"]);
                bk.Publisher = reader["Publisher"].ToString();
                bk.Qoh = Convert.ToInt32(reader["QOH"]);
                bk.Category = reader["Category"].ToString();
                bk.FirstName = reader["FirstName"].ToString();
                bk.LastName = reader["LastName"].ToString();
                bk.Email = reader["Email"].ToString();

                listB.Add(bk);
            }
            return listB;
        }


        public static Book SearchRecord(int bID)  // Search by ID
        {
            Book bk = new Book();
            SqlConnection conn = DBUtility.GetDBConnectionBook();
            SqlCommand cmdSelectById = new SqlCommand();
            cmdSelectById.Connection = conn;
            cmdSelectById.CommandText = "SELECT * FROM Book " + "WHERE Isbn = @ISBN";
            cmdSelectById.Parameters.AddWithValue("@ISBN", bID);
            SqlDataReader reader = cmdSelectById.ExecuteReader();
            if (reader.Read())
            {
                bk.Isbn = Convert.ToInt32(reader["ISBN"]);
                bk.AuthorId = Convert.ToInt32(reader["AuthorId"]);
                bk.Title = reader["Title"].ToString();
                bk.UnitPrice = Convert.ToInt32(reader["UnitPrize"]);
                bk.YearPublished = Convert.ToInt32(reader["YearPublished"]);
                bk.Publisher = reader["Publisher"].ToString();
                bk.Qoh = Convert.ToInt32(reader["QOH"]);
                bk.Category = reader["Category"].ToString();
                bk.FirstName = reader["FirstName"].ToString();
                bk.LastName = reader["LastName"].ToString();
                bk.Email = reader["Email"].ToString();
            }
            else
            {
                bk = null;
            }
            return bk;

        }

        public static Book SearchRecordByAuthorId(int bID)  // Search by ID
        {
            Book bk = new Book();
            SqlConnection conn = DBUtility.GetDBConnectionBook();
            SqlCommand cmdSelectById = new SqlCommand();
            cmdSelectById.Connection = conn;
            cmdSelectById.CommandText = "SELECT * FROM Book " + "WHERE AuthorId = @AuthorId";
            cmdSelectById.Parameters.AddWithValue("@AuthorId", bID);
            SqlDataReader reader = cmdSelectById.ExecuteReader();
            if (reader.Read())
            {
                bk.Isbn = Convert.ToInt32(reader["ISBN"]);
                bk.AuthorId = Convert.ToInt32(reader["AuthorId"]);
                bk.Title = reader["Title"].ToString();
                bk.UnitPrice = Convert.ToInt32(reader["UnitPrize"]);
                bk.YearPublished = Convert.ToInt32(reader["YearPublished"]);
                bk.Publisher = reader["Publisher"].ToString();
                bk.Qoh = Convert.ToInt32(reader["QOH"]);
                bk.Category = reader["Category"].ToString();
                bk.FirstName = reader["FirstName"].ToString();
                bk.LastName = reader["LastName"].ToString();
                bk.Email = reader["Email"].ToString();
            }
            else
            {
                bk = null;
            }
            return bk;

        }


        public static bool IsDuplicateId(int id)
        {
            Book bk = new Book();
            bk = SearchRecord(id);
            if (bk != null)
            {
                return true;
            }
            return false;
        }

        public static void SaveRecords(Book bk)
        {
            SqlConnection conn = DBUtility.GetDBConnectionBook();  //connect DB

            try
            {
                //create and customize an object of SqlCommand

                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = conn;
                cmdInsert.CommandText = "INSERT INTO Book (ISBN,AuthorId,Title,UnitPrize,YearPublished,Publisher,QOH,Category,FirstName,LastName,Email)" +
                    " VALUES(@ISBN,@AuthorId,@Title,@UnitPrize,@YearPublished,@Publisher,@QOH,@Category,@FirstName,@LastName,@Email)";

                cmdInsert.Parameters.AddWithValue("@ISBN", bk.Isbn);
                cmdInsert.Parameters.AddWithValue("@AuthorId", bk.AuthorId);
                cmdInsert.Parameters.AddWithValue("@Title", bk.Title);
                cmdInsert.Parameters.AddWithValue("@UnitPrize", bk.UnitPrice);
                cmdInsert.Parameters.AddWithValue("@YearPublished", bk.YearPublished);
                cmdInsert.Parameters.AddWithValue("@Publisher", bk.Publisher);
                cmdInsert.Parameters.AddWithValue("@QOH", bk.Qoh);
                cmdInsert.Parameters.AddWithValue("@Category", bk.Category);
                cmdInsert.Parameters.AddWithValue("@FirstName", bk.FirstName);
                cmdInsert.Parameters.AddWithValue("@LastName", bk.LastName);
                cmdInsert.Parameters.AddWithValue("@Email", bk.Email);


                cmdInsert.ExecuteNonQuery();            //Excute the inserted query
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally                          //clean the code and close database
            {
                conn.Close();                //close DB
                conn.Dispose();              //perform the job right away, will dispose the garbage
            }

        }
    }
}
