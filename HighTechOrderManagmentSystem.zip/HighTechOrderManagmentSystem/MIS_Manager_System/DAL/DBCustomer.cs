﻿using MIS_Manager_System.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIS_Manager_System.DAL
{
    public static class DBCustomer
    {
        public static List<Customer> GetAllRecords()
        {
            List<Customer> listC = new List<Customer>();

            using (SqlConnection conn = DBUtility.GetDBConnectionCustomer())
            {
                SqlCommand cmdAll = new SqlCommand("SELECT * FROM Customer", conn);
                SqlDataReader reader = cmdAll.ExecuteReader();
                Customer acustomer;
                while (reader.Read())
                {
                    acustomer = new Customer();
                    acustomer.customerId = Convert.ToInt32(reader["CustomerId"]);
                    acustomer.customerName = reader["CustomerName"].ToString();
                    acustomer.creditLimit = Convert.ToInt32(reader["CreditLimit"].ToString());
                    acustomer.streetNumber = reader["StreetName"].ToString();
                    acustomer.city = reader["City"].ToString();
                    acustomer.postalCode = reader["PostalCode"].ToString();
                    acustomer.phoneNumber = Convert.ToInt32(reader["PhoneNumber"].ToString());
                    acustomer.faxNumber = Convert.ToInt32(reader["FaxNumber"].ToString());
                    acustomer.email = reader["Email"].ToString();
                    listC.Add(acustomer);
                }
            }
            return listC;
        }
    }
}
